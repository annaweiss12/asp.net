using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace chapter2_1.Pages
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {

        }
    }
}
