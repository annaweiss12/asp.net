using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace chapter4_1.Pages
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {

        }
    }
}
