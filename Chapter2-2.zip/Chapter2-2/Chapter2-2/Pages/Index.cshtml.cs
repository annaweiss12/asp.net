using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Chapter2_2.Pages
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {

        }
    }
}
