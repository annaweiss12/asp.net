using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Chapter3_1.Pages
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {

        }
    }
}
